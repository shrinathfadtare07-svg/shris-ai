# Shri's AI — Streamlit App
**Built by Shrinath Fadtare**

A full-featured ChatGPT-style AI assistant with 5 modes, chat history, and transcript export.

---

## Setup & Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the app
```bash
streamlit run shris_ai_app.py
```

### 3. Open in browser
Streamlit will open automatically at `http://localhost:8501`

---

## How to use

1. **Enter your OpenAI API key** in the sidebar (get one at platform.openai.com)
2. **Pick a mode** from the sidebar:
   - 🏠 **Default** — general assistant for any question
   - 🎓 **Teacher** — step-by-step explanations and quizzes
   - 💻 **Developer** — code-first help for Python, Arduino, GUI
   - 🎨 **Creative** — stories, ideas, writing prompts
   - 🧠 **Quiz** — practice questions and flashcards
3. **Type your question** or click a suggestion card
4. **Export transcript** anytime with the Export button

---

## Features

- 5 AI modes with distinct personalities and system prompts
- Per-mode chat history (switching modes keeps each conversation separate)
- Streaming responses (text appears word-by-word)
- One-click transcript download as .txt
- Clear chat per mode
- Clean, professional UI with custom CSS
- Works with GPT-4o

---

## Extending the app

Add more modes by editing the `MODES` dictionary in `shris_ai_app.py`:

```python
"MyMode": {
    "icon": "🚀",
    "color": "#...",
    "bg": "#...",
    "system": "You are Shri's AI in MyMode. ...",
    "desc": "Short description shown under the header.",
    "starters": ["Starter question 1", "Starter question 2"],
}
```
