import streamlit as st
import openai
from datetime import datetime

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Shri's AI",
    page_icon="✨",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    /* Main background */
    .stApp { background-color: #f9f9f7; }

    /* Sidebar */
    [data-testid="stSidebar"] {
        background-color: #ffffff;
        border-right: 1px solid #e8e8e4;
    }

    /* Chat input */
    .stChatInput textarea {
        border-radius: 12px !important;
        border: 1.5px solid #d0d0cc !important;
    }
    .stChatInput textarea:focus {
        border-color: #7f77dd !important;
        box-shadow: 0 0 0 3px #eeedfe !important;
    }

    /* Hide default header */
    #MainMenu, header, footer { visibility: hidden; }

    /* User message bubble */
    [data-testid="stChatMessageContent"] {
        border-radius: 12px;
    }

    /* Mode badge */
    .mode-badge {
        display: inline-block;
        padding: 3px 10px;
        border-radius: 99px;
        font-size: 12px;
        font-weight: 500;
        margin-bottom: 8px;
    }
</style>
""", unsafe_allow_html=True)

# ── Mode definitions ──────────────────────────────────────────────────────────
MODES = {
    "Default": {
        "icon": "🏠",
        "color": "#534AB7",
        "bg": "#EEEDFE",
        "system": (
            "You are Shri's AI, a smart and friendly assistant created by Shrinath Fadtare. "
            "Help with coding, teaching, creativity, and any question the user has. "
            "Be clear, concise, and encouraging. Format code in code blocks."
        ),
        "desc": "General-purpose assistant for any topic.",
        "starters": [
            "What can you help me with?",
            "Explain machine learning simply",
            "What is the capital of France?",
        ],
    },
    "Teacher": {
        "icon": "🎓",
        "color": "#0F6E56",
        "bg": "#E1F5EE",
        "system": (
            "You are Shri's AI in Teacher Mode, created by Shrinath Fadtare. "
            "Explain every concept with step-by-step breakdowns, real-world analogies, and examples. "
            "After each explanation, offer to quiz the student or give them practice problems. "
            "Be patient, encouraging, and age-appropriate for high school and college students."
        ),
        "desc": "Step-by-step explanations, analogies, and quizzes.",
        "starters": [
            "Teach me Python basics",
            "Explain recursion with an example",
            "Quiz me on OOP concepts",
        ],
    },
    "Developer": {
        "icon": "💻",
        "color": "#185FA5",
        "bg": "#E6F1FB",
        "system": (
            "You are Shri's AI in Developer Mode, created by Shrinath Fadtare. "
            "Provide clean, commented, production-ready code for Python, Arduino, Tkinter GUI, and web projects. "
            "Always explain what the code does, suggest edge cases to test, and recommend best practices. "
            "Format all code in properly labeled code blocks."
        ),
        "desc": "Code-first. Python, Arduino, GUI, debugging.",
        "starters": [
            "Write an Arduino LED blink sketch",
            "Build a Python Tkinter calculator",
            "Debug: NameError: name 'x' is not defined",
        ],
    },
    "Creative": {
        "icon": "🎨",
        "color": "#993556",
        "bg": "#FBEAF0",
        "system": (
            "You are Shri's AI in Creative Mode, created by Shrinath Fadtare. "
            "Help brainstorm imaginative stories, innovative project ideas, writing prompts, poems, and creative concepts. "
            "Be expressive, original, and inspiring. Encourage experimentation and out-of-the-box thinking."
        ),
        "desc": "Stories, project ideas, prompts, and imagination.",
        "starters": [
            "Give me a sci-fi story idea",
            "Brainstorm 5 innovative student projects",
            "Write a poem about coding",
        ],
    },
    "Quiz": {
        "icon": "🧠",
        "color": "#854F0B",
        "bg": "#FAEEDA",
        "system": (
            "You are Shri's AI in Quiz Mode, created by Shrinath Fadtare. "
            "Generate clear, engaging multiple-choice or short-answer questions on any topic the user requests. "
            "After the user answers, give immediate feedback, explain the correct answer, and offer the next question. "
            "Keep track of the score within the conversation."
        ),
        "desc": "Practice questions, flashcards, and self-testing.",
        "starters": [
            "Quiz me on Python — 5 questions",
            "Test me on photosynthesis",
            "Give me Arduino MCQs",
        ],
    },
}

# ── Session state init ────────────────────────────────────────────────────────
if "mode" not in st.session_state:
    st.session_state.mode = "Default"
if "chats" not in st.session_state:
    st.session_state.chats = {"Default": [], "Teacher": [], "Developer": [], "Creative": [], "Quiz": []}
if "api_key" not in st.session_state:
    st.session_state.api_key = ""

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ✨ Shri's AI")
    st.markdown("<small style='color:#888'>by Shrinath Fadtare</small>", unsafe_allow_html=True)
    st.divider()

    # API Key input
    st.markdown("**API Key**")
    api_key_input = st.text_input(
        "OpenAI API Key",
        value=st.session_state.api_key,
        type="password",
        placeholder="sk-...",
        label_visibility="collapsed",
    )
    if api_key_input:
        st.session_state.api_key = api_key_input

    st.divider()

    # Mode selector
    st.markdown("**Mode**")
    for mode_name, cfg in MODES.items():
        active = st.session_state.mode == mode_name
        btn_label = f"{cfg['icon']} {mode_name}"
        if active:
            st.markdown(
                f"<div style='background:{cfg['bg']};color:{cfg['color']};padding:8px 12px;"
                f"border-radius:8px;font-size:14px;font-weight:500;margin-bottom:4px'>"
                f"{btn_label} ✓</div>",
                unsafe_allow_html=True,
            )
        else:
            if st.button(btn_label, key=f"mode_{mode_name}", use_container_width=True):
                st.session_state.mode = mode_name
                st.rerun()

    st.divider()

    # Stats
    current_msgs = st.session_state.chats[st.session_state.mode]
    user_msgs = [m for m in current_msgs if m["role"] == "user"]
    st.markdown(f"**Messages:** {len(current_msgs)}")
    st.markdown(f"**Questions asked:** {len(user_msgs)}")

    st.divider()

    # Actions
    col1, col2 = st.columns(2)
    with col1:
        if st.button("🗑 Clear", use_container_width=True):
            st.session_state.chats[st.session_state.mode] = []
            st.rerun()
    with col2:
        # Build transcript
        transcript_lines = [
            f"SHRI'S AI — TRANSCRIPT",
            f"Mode: {st.session_state.mode}",
            f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            "=" * 40, ""
        ]
        for m in current_msgs:
            speaker = "You" if m["role"] == "user" else "Shri's AI"
            transcript_lines.append(f"{speaker}:")
            transcript_lines.append(m["content"])
            transcript_lines.append("")
        transcript = "\n".join(transcript_lines)

        st.download_button(
            "📄 Export",
            data=transcript,
            file_name=f"shris-ai-{st.session_state.mode.lower()}.txt",
            mime="text/plain",
            use_container_width=True,
        )

    st.divider()
    st.markdown("<small style='color:#aaa'>Powered by OpenAI · Built by Shrinath Fadtare</small>", unsafe_allow_html=True)

# ── Main area ─────────────────────────────────────────────────────────────────
mode = st.session_state.mode
cfg = MODES[mode]
messages = st.session_state.chats[mode]

# Header
col_h1, col_h2 = st.columns([3, 1])
with col_h1:
    st.markdown(
        f"<h2 style='margin:0;padding-top:8px'>{cfg['icon']} {mode} Mode</h2>"
        f"<p style='color:#888;font-size:14px;margin-top:2px'>{cfg['desc']}</p>",
        unsafe_allow_html=True,
    )
with col_h2:
    st.markdown("<br>", unsafe_allow_html=True)

st.divider()

# Welcome / suggestion cards when no messages
if not messages:
    st.markdown(
        f"<div style='text-align:center;padding:20px 0 10px'>"
        f"<div style='font-size:40px'>{cfg['icon']}</div>"
        f"<h3 style='margin-top:8px'>How can I help you today?</h3>"
        f"<p style='color:#888;font-size:14px'>{cfg['desc']}</p>"
        f"</div>",
        unsafe_allow_html=True,
    )
    cols = st.columns(len(cfg["starters"]))
    for i, starter in enumerate(cfg["starters"]):
        with cols[i]:
            if st.button(starter, key=f"starter_{i}", use_container_width=True):
                messages.append({"role": "user", "content": starter})
                st.rerun()
    st.markdown("<br>", unsafe_allow_html=True)

# Render chat messages
for msg in messages:
    with st.chat_message(msg["role"], avatar="✨" if msg["role"] == "assistant" else "👤"):
        st.markdown(msg["content"])

# Chat input
user_input = st.chat_input(f"Message Shri's AI ({mode} mode)…")

if user_input:
    if not st.session_state.api_key:
        st.error("Please enter your OpenAI API key in the sidebar to start chatting.")
        st.stop()

    messages.append({"role": "user", "content": user_input})

    with st.chat_message("user", avatar="👤"):
        st.markdown(user_input)

    with st.chat_message("assistant", avatar="✨"):
        with st.spinner("Thinking…"):
            try:
                client = openai.OpenAI(api_key=st.session_state.api_key)
                api_messages = [{"role": "system", "content": cfg["system"]}] + messages
                response = client.chat.completions.create(
                    model="gpt-4o",
                    messages=api_messages,
                    stream=True,
                )
                reply = st.write_stream(response)
            except openai.AuthenticationError:
                reply = "Invalid API key. Please check your OpenAI API key in the sidebar."
                st.error(reply)
            except openai.RateLimitError:
                reply = "Rate limit reached. Please wait a moment and try again."
                st.warning(reply)
            except Exception as e:
                reply = f"Error: {str(e)}"
                st.error(reply)

    messages.append({"role": "assistant", "content": reply})
    st.session_state.chats[mode] = messages
